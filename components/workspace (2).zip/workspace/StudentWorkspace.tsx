'use client';

import dynamic from 'next/dynamic';
import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { useWorkspaceStore } from '@/stores/useWorkspaceStore';
import { WORKSPACE_DEFAULTS } from '@/lib/workspace-defaults';
import { ColorPopover } from './ColorPopover';
import { TextStyleControls } from './TextStyleControls';
import { AccessibleToolButton } from './AccessibleToolButton';
import { RichTextManagerV2 } from './RichTextManagerV2';
import { DEFAULT_COLORS } from '@/lib/workspace-swatches';
import { useEditingTextStore } from '@/stores/editingTextStore';
import { useDerivedTextStyle } from '@/stores/useWorkspaceStore';
import '@excalidraw/excalidraw/index.css';

interface PageData {
  id: string;
  index: number;
  scene: any;
  orientation: 'portrait' | 'landscape';
}

const Excalidraw = dynamic(
  () => import('@excalidraw/excalidraw').then((mod) => ({ default: mod.Excalidraw })),
  { ssr: false }
);

interface StudentWorkspaceProps {
  submissionId?: string;
}

export default function StudentWorkspace({ submissionId = 'demo-submission' }: StudentWorkspaceProps) {
  const [excalidrawAPI, setExcalidrawAPI] = useState<any>(null);
  const [isMounted, setIsMounted] = useState<boolean>(false);
  const isInitialized = useRef<boolean>(false);
  const { editingTextId, isEditing } = useEditingTextStore();
  const { derivedStyle, isMixed, hasSelection } = useDerivedTextStyle(excalidrawAPI);
  
  // Ensure derivedStyle always has valid values
  const safeStyle = {
    fontSize: derivedStyle?.fontSize ?? 20,
    color: derivedStyle?.textColor ?? '#000000',
    bold: derivedStyle?.bold ?? false,
    italic: derivedStyle?.italic ?? false,
    underline: derivedStyle?.underline ?? false,
    fontFamily: derivedStyle?.fontFamily ?? 'Arial, sans-serif',
    lineHeight: derivedStyle?.lineHeight ?? 1.2,
    align: derivedStyle?.align ?? 'left'
  };
  const [activeTool, setActiveTool] = useState<string>('select');
  const [strokeWidth, setStrokeWidth] = useState<number>(1);
  const [fontSize, setFontSize] = useState<number>(20);
  const [strokeColor, setStrokeColor] = useState<string>(DEFAULT_COLORS.stroke);
  const [textColor, setTextColor] = useState<string>(DEFAULT_COLORS.text);
  const [highlighterColor, setHighlighterColor] = useState<string>(DEFAULT_COLORS.highlighter);
  const [isBold, setIsBold] = useState<boolean>(false);
  const [isItalic, setIsItalic] = useState<boolean>(false);
  const [isUnderlined, setIsUnderlined] = useState<boolean>(false);
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [pages, setPages] = useState<PageData[]>([]);
  const [currentPageIndex, setCurrentPageIndex] = useState<number>(0);
  const [isLoadingPages, setIsLoadingPages] = useState<boolean>(true);
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isSavingRef = useRef<boolean>(false);
  
  // Extension hooks for future features
  const [showPageMenu, setShowPageMenu] = useState<boolean>(false);
  const [presenceUsers, setPresenceUsers] = useState<any[]>([]);
  const [showCommentsPanel, setShowCommentsPanel] = useState<boolean>(false);
  
  const { 
    setSaveState, 
    editingTextId: workspaceEditingTextId, 
    setEditingTextId: setWorkspaceEditingTextId,
    selectedElementIds = [], // Provide default empty array
    setSelectedElementIds,
    applyTextStyleToSelection,
    textDefaults
  } = useWorkspaceStore();

  const getToolSettings = useCallback((toolType: string) => {
    switch (toolType) {
      case 'highlighter':
        return {
          currentItemStrokeColor: highlighterColor,
          currentItemBackgroundColor: 'transparent',
          currentItemOpacity: 60,
          currentItemRoughness: 0,
        };
      case 'pencil':
        return {
          currentItemStrokeColor: strokeColor,
          currentItemBackgroundColor: 'transparent',
          currentItemOpacity: 100,
          currentItemRoughness: 1,
        };
      case 'eraser':
        return {
          currentItemStrokeColor: strokeColor, // Use normal color, let Excalidraw handle erasing
          currentItemBackgroundColor: 'transparent',
          currentItemOpacity: 100,
          currentItemRoughness: 1,
        };
      case 'text':
        return {
          currentItemStrokeColor: textColor,
          currentItemBackgroundColor: 'transparent',
          currentItemOpacity: 100,
          currentItemFontFamily: isBold || isItalic ? (isBold && isItalic ? '3' : (isBold ? '2' : '1')) : '1',
        };
      default:
        return {
          currentItemStrokeColor: strokeColor,
          currentItemBackgroundColor: 'transparent',
          currentItemOpacity: 100,
          currentItemRoughness: 1,
        };
    }
  }, [highlighterColor, strokeColor, textColor, isBold, isItalic]);

  const handleToolChange = useCallback((toolType: string) => {
    if (!excalidrawAPI || !isMounted) return;
    
    // If currently editing text, commit changes before switching tools
    if (workspaceEditingTextId && toolType !== 'text') {
      console.log('🎯 Committing text edit before tool change');
      setWorkspaceEditingTextId(null);
      // Force exit text editing mode in Excalidraw
      excalidrawAPI.updateScene({
        appState: {
          editingElement: null
        }
      });
    }
    
    try {
      // Map tool names to Excalidraw tool types
      const toolMapping: Record<string, string> = {
        'select': 'selection',
        'pencil': 'freedraw',
        'text': 'text', 
        'eraser': 'eraser', // Try the actual eraser tool
        'highlighter': 'freedraw'
      };
      
      const actualTool = toolMapping[toolType] || toolType;
      const toolSettings = getToolSettings(toolType);
      
      // Use both setActiveTool AND updateScene for reliable tool switching
      excalidrawAPI.setActiveTool({ type: actualTool });
      
      // Small delay to ensure tool is set before updating scene
      setTimeout(() => {
        if (excalidrawAPI) {
          excalidrawAPI.updateScene({
            appState: {
              activeTool: { type: actualTool },
              currentItemStrokeWidth: strokeWidth,
              currentItemFontSize: fontSize,
              ...toolSettings,
            }
          });
        }
      }, 10); // Very small delay
      
      setActiveTool(toolType);
    } catch (error) {
      console.error('Tool change error:', error);
      setSaveState('error');
    }
  }, [excalidrawAPI, isMounted, strokeWidth, fontSize, getToolSettings, setSaveState, workspaceEditingTextId, setWorkspaceEditingTextId]);

  const handleWidthChange = useCallback((newWidth: number) => {
    setStrokeWidth(newWidth);
    
    if (!excalidrawAPI || !isMounted) return;
    
    try {
      const currentAppState = excalidrawAPI.getAppState();
      excalidrawAPI.updateScene({
        appState: {
          ...currentAppState,
          currentItemStrokeWidth: newWidth,
        }
      });
      
      // Update selected elements
      const selectedElements = excalidrawAPI.getSceneElements().filter((el: any) => el.isSelected);
      if (selectedElements.length > 0) {
        const updatedElements = excalidrawAPI.getSceneElements().map((el: any) => {
          if (el.isSelected) {
            return { ...el, strokeWidth: newWidth };
          }
          return el;
        });
        excalidrawAPI.updateScene({ elements: updatedElements });
      }
    } catch (error) {
      console.error('Width change error:', error);
    }
  }, [excalidrawAPI, isMounted]);

  const handleFontSizeChange = useCallback((newSize: number) => {
    console.log('🔧 Font size change initiated:', { oldSize: fontSize, newSize });
    setFontSize(newSize);
    
    if (!excalidrawAPI || !isMounted) return;
    
    // Update the app state font size for future elements
    try {
      const currentAppState = excalidrawAPI.getAppState();
      excalidrawAPI.updateScene({
        appState: {
          ...currentAppState,
          currentItemFontSize: newSize,
        }
      });
    } catch (error) {
      console.error('Error updating app state font size:', error);
    }
    
    // Apply font size using centralized selection-aware function
    applyTextStyleToSelection({ fontSize: newSize }, excalidrawAPI);
    
    // IMMEDIATE overlay height update - find any active text editing overlay
    // Do this synchronously before the timeout to ensure immediate visual feedback
    const overlayElement = document.querySelector('[data-rich-text-overlay="true"]') as HTMLElement;
    if (overlayElement && workspaceEditingTextId) {
      console.log('🔧 Immediately updating overlay height for font size:', newSize);
      // Calculate new height based on font size
      const newHeight = newSize * 1.4;
      overlayElement.style.minHeight = `${newHeight}px`;
      overlayElement.style.fontSize = `${newSize}px`;
      
      // Force the browser to recalculate layout immediately
      overlayElement.getBoundingClientRect(); // Force layout calculation
    }
    
    // Force immediate update of any active text editing overlay
    // This creates a small delay to ensure the element is updated first
    setTimeout(() => {
      console.log('🔧 Triggering post-font-size update check');
      // Dispatch a custom event that the overlay can listen for
      window.dispatchEvent(new CustomEvent('font-size-changed', { 
        detail: { fontSize: newSize, elementId: workspaceEditingTextId } 
      }));
    }, 10); // Reduced delay for faster response
    
    // Note: The RichTextManagerV2 will handle overlay updates through its monitoring system
  }, [excalidrawAPI, isMounted, applyTextStyleToSelection, fontSize, workspaceEditingTextId]);

  // Centralized text style handlers
  const handleBoldToggle = useCallback((bold: boolean) => {
    applyTextStyleToSelection({ bold }, excalidrawAPI);
  }, [applyTextStyleToSelection, excalidrawAPI]);

  const handleItalicToggle = useCallback((italic: boolean) => {
    applyTextStyleToSelection({ italic }, excalidrawAPI);
  }, [applyTextStyleToSelection, excalidrawAPI]);

  const handleUnderlineToggle = useCallback((underline: boolean) => {
    applyTextStyleToSelection({ underline }, excalidrawAPI);
  }, [applyTextStyleToSelection, excalidrawAPI]);

  const handleColorChange = useCallback((color: string) => {
    setTextColor(color);
    applyTextStyleToSelection({ textColor: color }, excalidrawAPI);
  }, [applyTextStyleToSelection, excalidrawAPI]);

  const handleExcalidrawAPIReady = useCallback((api: any) => {
    if (!isMounted) {
      console.warn('Component not mounted yet, deferring API setup');
      return;
    }
    
    console.log('Setting up Excalidraw API');
    setExcalidrawAPI(api);
  }, [isMounted]);

  const handleChange = useCallback((elements: any, appState: any) => {
    // RESIZE CONSTRAINT LOGIC - Fix text box resize behavior
    // Detect text element resizing and constrain inappropriate dimension changes
    const currentSelectedIds = Object.keys(appState?.selectedElementIds ?? {});
    
    if (currentSelectedIds.length === 1) {
      const selectedElement = elements.find((el: any) => currentSelectedIds.includes(el.id));
      
      if (selectedElement && selectedElement.type === 'text') {
        // Check if this text element was resized by comparing with previous state
        const previousElement = excalidrawAPI?.getSceneElements()?.find((el: any) => el.id === selectedElement.id);
        
        if (previousElement && (
          Math.abs(selectedElement.width - (previousElement.width || 0)) > 1 ||
          Math.abs(selectedElement.height - (previousElement.height || 0)) > 1
        )) {
          console.log('🔄 Text element resize detected:', {
            id: selectedElement.id,
            oldWidth: previousElement.width,
            newWidth: selectedElement.width,
            oldHeight: previousElement.height,
            newHeight: selectedElement.height
          });
          
          // Determine resize type based on the change pattern
          const widthChanged = Math.abs(selectedElement.width - (previousElement.width || 0)) > 1;
          const heightChanged = Math.abs(selectedElement.height - (previousElement.height || 0)) > 1;
          
          // If only height changed, this is horizontal edge drag - constrain width to original
          if (heightChanged && !widthChanged) {
            console.log('📏 Horizontal edge drag detected - constraining width, allowing height');
            // Horizontal edge resize - maintain the original width, allow height change
            const constrainedElements = elements.map((el: any) => {
              if (el.id === selectedElement.id) {
                return {
                  ...el,
                  width: previousElement.width, // Restore original width
                  height: selectedElement.height // Keep new height
                };
              }
              return el;
            });
            
            // Update the scene with constrained dimensions
            setTimeout(() => {
              if (excalidrawAPI) {
                excalidrawAPI.updateScene({
                  elements: constrainedElements,
                  commitToHistory: false // Don't create undo history for constraints
                });
              }
            }, 0);
            
            console.log('✅ Applied horizontal edge constraint (width preserved)');
          }
          // If only width changed, this is vertical edge drag - constrain height to original  
          else if (widthChanged && !heightChanged) {
            console.log('� Vertical edge drag - allowing width-only resize');
            // Vertical edge resize - allow width change (no constraint needed, this is correct)
          }
          // If both width and height changed, this is corner drag - allow both
          else if (widthChanged && heightChanged) {
            console.log('� Corner drag - allowing both dimensions to resize');
            // Corner resize - allow both dimensions to change (default behavior)
          }
        }
      }
    }
    
    // Track selection changes - Excalidraw uses selectedElementIds as an object with IDs as keys
    const previousSelectedIds = selectedElementIds || []; // Handle undefined case
    const previousSelectedIdsSet = new Set(previousSelectedIds);
    const currentSelectedIdsSet = new Set(currentSelectedIds);
    
    // Update selection if it changed
    const selectionChanged = 
      currentSelectedIds.length !== previousSelectedIds.length ||
      currentSelectedIds.some((id: string) => !previousSelectedIdsSet.has(id)) ||
      previousSelectedIds.some(id => !currentSelectedIdsSet.has(id));
    
    if (selectionChanged) {
      console.log('📝 Selection changed:', {
        previous: previousSelectedIds,
        current: currentSelectedIds
      });
      setSelectedElementIds(currentSelectedIds);
    }
    
    // Track text editing state changes
    const currentEditingElement = appState?.editingElement;
    
    // Set workspace editing state when entering text edit mode
    if (currentEditingElement && !workspaceEditingTextId) {
      const editingElement = elements.find((el: any) => el.id === currentEditingElement);
      if (editingElement && editingElement.type === 'text') {
        console.log('🎯 Setting workspace editing state:', currentEditingElement);
        setWorkspaceEditingTextId(currentEditingElement);
      }
    }
    
    // Clear workspace editing state when exiting text edit mode
    if (!currentEditingElement && workspaceEditingTextId) {
      console.log('🎯 Clearing workspace editing state');
      setWorkspaceEditingTextId(null);
    }
    
    // Preserve text editing state during changes
    if (isEditing() && !appState?.editingElement) {
      console.log('🎯 Detected editing state loss - restoring it');
      // Don't clear the global editing state yet, let RichTextManagerV2 handle it
    }
    
    // Update zoom level from app state (debounced to prevent excessive re-renders)
    if (appState?.zoom) {
      const newZoomLevel = Math.round(appState.zoom.value * 100);
      if (Math.abs(newZoomLevel - zoomLevel) > 5) { // Only update if significant change
        setZoomLevel(newZoomLevel);
      }
    }
    
    // Debounced autosave (800ms) - only if we have valid pages
    if (pages.length > 0 && currentPageIndex < pages.length && currentPageIndex >= 0) {
      const currentPage = pages[currentPageIndex];
      if (!currentPage) return;
      
      const scene = { elements, appState };
      
      // Clear existing timeout
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }
      
      // Only set saving state if we're not already saving
      // setSaveState('saving'); // Remove this to prevent constant state updates
      
      // Set new timeout for autosave
      saveTimeoutRef.current = setTimeout(async () => {
        if (isSavingRef.current) return; // Prevent concurrent saves
        
        try {
          isSavingRef.current = true;
          setSaveState('saving');
          const response = await fetch(`/api/submissions/${submissionId}/pages/${currentPage.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ scene })
          });
          
          if (response.ok) {
            setSaveState('saved');
            console.log('📄 Page auto-saved successfully');
          } else {
            setSaveState('error');
            console.error('Failed to save page');
          }
        } catch (error) {
          setSaveState('error');
          console.error('Error saving page:', error);
        } finally {
          isSavingRef.current = false;
        }
      }, 800);
    }
  }, [pages, currentPageIndex, submissionId, setSaveState, zoomLevel, workspaceEditingTextId, setWorkspaceEditingTextId, isEditing, setSelectedElementIds]); // Removed selectedElementIds from deps to prevent loops

  // Load pages from API
  const loadPages = useCallback(async () => {
    try {
      setIsLoadingPages(true);
      const response = await fetch(`/api/submissions/${submissionId}/pages`);
      
      if (response.ok) {
        const pagesData: PageData[] = await response.json();
        setPages(pagesData);
        console.log(`📚 Loaded ${pagesData.length} pages`);
      } else {
        console.error('Failed to load pages');
        // Create default page
        const defaultPage: PageData = {
          id: `${submissionId}-page-1`,
          index: 0,
          scene: { elements: [], appState: {} },
          orientation: 'portrait'
        };
        setPages([defaultPage]);
      }
    } catch (error) {
      console.error('Error loading pages:', error);
    } finally {
      setIsLoadingPages(false);
    }
  }, [submissionId]);

  // Component mounting effect
  useEffect(() => {
    setIsMounted(true);
    return () => setIsMounted(false);
  }, []);

  // Prevent clearing text editing when clicking on toolbar  
  useEffect(() => {
    const handleGlobalClick = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      
      // Check if click is on overlay
      const isOverlayClick = target.closest('[data-rich-text-overlay="true"]');
      
      // Check if click is on toolbar or its children
      const toolbarElement = target.closest('[data-toolbar="true"]');
      const isToolbarClick = !!toolbarElement;
      
      // Check if click is on any UI control that should preserve selection
      const isUIControl = target.closest('input, button, select, [role="button"], [role="slider"]');
      
      // Check if we're in text editing mode
      const isInTextEditingMode = isEditing() || workspaceEditingTextId || editingTextId;
      
      if (isInTextEditingMode) {
        // Allow clicks on overlay and toolbar
        if (isOverlayClick || isToolbarClick || isUIControl) {
          console.log('🎯 Allowed click during text editing:', {
            isOverlayClick: !!isOverlayClick,
            isToolbarClick,
            isUIControl: !!isUIControl
          });
          return;
        }
        
        // Block all other clicks during text editing
        console.log('🎯 Blocking click during text editing - preserving editing state');
        event.stopPropagation();
        event.preventDefault();
        return;
      }
      
      // Normal click handling when not editing
      if ((isToolbarClick || isUIControl) && hasSelectedTextElements()) {
        console.log('🎯 UI control click detected - preserving selection state', {
          isToolbarClick,
          isUIControl: !!isUIControl,
          hasSelection: hasSelectedTextElements()
        });
        
        // Prevent event from reaching Excalidraw's stage handlers
        event.stopPropagation();
        event.preventDefault();
      }
    };

    // Use capture phase to intercept before Excalidraw handles it
    document.addEventListener('click', handleGlobalClick, true);
    document.addEventListener('mousedown', handleGlobalClick, true);
    document.addEventListener('pointerdown', handleGlobalClick, true);
    
    return () => {
      document.removeEventListener('click', handleGlobalClick, true);
      document.removeEventListener('mousedown', handleGlobalClick, true);
      document.removeEventListener('pointerdown', handleGlobalClick, true);
    };
  }, [isEditing, workspaceEditingTextId, editingTextId]);

  // Helper function to check if any text elements are selected
  const hasSelectedTextElements = useCallback(() => {
    if (!excalidrawAPI) return false;
    try {
      const selectedElements = excalidrawAPI.getSceneElements().filter((el: any) => el.isSelected);
      return selectedElements.some((el: any) => el.type === 'text');
    } catch {
      return false;
    }
  }, [excalidrawAPI]);

  // Load pages on mount
  useEffect(() => {
    loadPages();
  }, [loadPages]);

  // Initialize or switch pages in Excalidraw
  useEffect(() => {
    if (!excalidrawAPI || !isMounted || isLoadingPages || pages.length === 0) return;
    
    const currentPage = pages[currentPageIndex];
    if (!currentPage) return;
    
    console.log(`🔄 Loading page ${currentPageIndex + 1}: ${currentPage.id}`);
    
    try {
      // Load the page scene into Excalidraw
      const scene = currentPage.scene || { elements: [], appState: {} };
      
      excalidrawAPI.updateScene({ 
        elements: scene.elements || [],
        appState: { 
          viewBackgroundColor: '#FFFFFF',
          currentItemStrokeColor: DEFAULT_COLORS.stroke,
          currentItemBackgroundColor: 'transparent',
          currentItemStrokeWidth: 1,
          currentItemRoughness: 1,
          currentItemOpacity: 100,
          viewModeEnabled: false, // Set to false for students, can be customized later
          zenModeEnabled: true,
          ...scene.appState
        } 
      });
      
      console.log(`✅ Page ${currentPageIndex + 1} loaded successfully`);
      setSaveState('saved');
    } catch (error) {
      console.error('Failed to load page scene:', error);
    }
  }, [excalidrawAPI, isMounted, isLoadingPages, pages, currentPageIndex, setSaveState]); // Removed dynamic color/width dependencies

  // Initialize default tool after API is ready
  useEffect(() => {
    if (!excalidrawAPI || !isMounted) return;
    
    // Set default tool to pencil for drawing - only run once when API is ready
    setTimeout(() => {
      try {
        handleToolChange('pencil');
        console.log('🎨 Default tool set to pencil');
      } catch (error) {
        console.error('Failed to set default tool:', error);
      }
    }, 200);
  }, [excalidrawAPI, isMounted]);

  // Handle Tab key for text indentation with caret positioning
  useEffect(() => {
    if (!excalidrawAPI || !isMounted) return;
    
    const handleKeyDown = (e: KeyboardEvent) => {
      // Global keyboard shortcuts (only when not editing text)
      const appState = excalidrawAPI.getAppState();
      const elements = excalidrawAPI.getSceneElements();
      const editingElement = elements.find((el: any) => el.id === appState.editingElement);
      const isEditingText = editingElement && editingElement.type === 'text';
      
      // Handle Escape key to exit text editing
      if (e.key === 'Escape' && (isEditingText || workspaceEditingTextId)) {
        e.preventDefault();
        console.log('🎯 Escape pressed - exiting text editing');
        setWorkspaceEditingTextId(null);
        excalidrawAPI.updateScene({
          appState: {
            editingElement: null
          }
        });
        return;
      }
      
      // Block all other shortcuts during text editing
      if (isEditingText || workspaceEditingTextId) {
        // Allow basic text editing keys to pass through
        const allowedKeys = ['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 
                           'Home', 'End', 'PageUp', 'PageDown', 'Tab', 'Enter'];
        
        // Allow Ctrl/Cmd combinations for text editing
        const isTextEditingShortcut = (e.ctrlKey || e.metaKey) && 
          ['a', 'c', 'v', 'x', 'z', 'y'].includes(e.key.toLowerCase());
        
        if (!allowedKeys.includes(e.key) && !isTextEditingShortcut && e.key.length === 1) {
          // Allow regular character input
          return;
        } else if (!allowedKeys.includes(e.key) && !isTextEditingShortcut) {
          console.log('🎯 Blocking shortcut during text editing:', e.key);
          e.preventDefault();
          e.stopPropagation();
          return;
        }
        
        // If we get here, it's an allowed key for text editing
        return;
      }
      
      if (!isEditingText && !workspaceEditingTextId) {
        const isCmdCtrl = e.metaKey || e.ctrlKey;
        
        // Undo/Redo shortcuts
        if (isCmdCtrl && e.key === 'z' && !e.shiftKey) {
          e.preventDefault();
          excalidrawAPI?.history.undo();
          return;
        }
        if (isCmdCtrl && (e.key === 'Z' || (e.key === 'z' && e.shiftKey))) {
          e.preventDefault();
          excalidrawAPI?.history.redo();
          return;
        }
        
        // Zoom shortcuts
        if (isCmdCtrl && (e.key === '=' || e.key === '+')) {
          e.preventDefault();
          const newZoom = Math.min(300, zoomLevel + 25);
          setZoomLevel(newZoom);
          return;
        }
        if (isCmdCtrl && (e.key === '-' || e.key === '_')) {
          e.preventDefault();
          const newZoom = Math.max(25, zoomLevel - 25);
          setZoomLevel(newZoom);
          return;
        }
        
        // Width nudge shortcuts with [ and ]
        if (e.key === '[') {
          e.preventDefault();
          const newWidth = Math.max(1, strokeWidth - 1);
          handleWidthChange(newWidth);
          return;
        }
        if (e.key === ']') {
          e.preventDefault();
          const newWidth = Math.min(10, strokeWidth + 1);
          handleWidthChange(newWidth);
          return;
        }
      }
      
      if ((e.key === 'Tab') && excalidrawAPI) {
        const appState = excalidrawAPI.getAppState();
        const elements = excalidrawAPI.getSceneElements();
        
        // Only handle if we're editing a text element
        const editingElement = elements.find((el: any) => el.id === appState.editingElement);
        if (editingElement && editingElement.type === 'text') {
          e.preventDefault();
          e.stopPropagation();
          
          const textElement = editingElement;
          const currentText = textElement.text || '';
          const isShiftTab = e.shiftKey;
          
          if (isShiftTab) {
            // Shift+Tab: Remove leading spaces (unindent)
            const lines = currentText.split('\n');
            const updatedLines = lines.map((line: string) => {
              // Remove up to 2 leading spaces
              if (line.startsWith('  ')) {
                return line.substring(2);
              } else if (line.startsWith(' ')) {
                return line.substring(1);
              }
              return line;
            });
            
            const updatedText = updatedLines.join('\n');
            
            const updatedElements = elements.map((el: any) => {
              if (el.id === editingElement.id) {
                return { ...el, text: updatedText };
              }
              return el;
            });
            
            excalidrawAPI.updateScene({ elements: updatedElements });
          } else {
            // Tab: Insert 2 spaces at current position
            const selection = window.getSelection();
            const activeElement = document.activeElement;
            
            if (activeElement && activeElement.tagName === 'TEXTAREA') {
              // We have focus in the text editor
              const textarea = activeElement as HTMLTextAreaElement;
              const start = textarea.selectionStart;
              const end = textarea.selectionEnd;
              const spaces = '  '; // 2 spaces for indentation
              
              const newText = currentText.substring(0, start) + spaces + currentText.substring(end);
              const newCaretPos = start + spaces.length;
              
              const updatedElements = elements.map((el: any) => {
                if (el.id === editingElement.id) {
                  return { ...el, text: newText };
                }
                return el;
              });
              
              excalidrawAPI.updateScene({ elements: updatedElements });
              
              // Restore caret position after the update
              setTimeout(() => {
                if (textarea) {
                  textarea.setSelectionRange(newCaretPos, newCaretPos);
                }
              }, 0);
            } else {
              // Fallback: append spaces at the end
              const updatedText = currentText + '  ';
              
              const updatedElements = elements.map((el: any) => {
                if (el.id === editingElement.id) {
                  return { ...el, text: updatedText };
                }
                return el;
              });
              
              excalidrawAPI.updateScene({ elements: updatedElements });
            }
          }
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown, true); // Use capture phase
    return () => document.removeEventListener('keydown', handleKeyDown, true);
  }, [excalidrawAPI, isMounted, workspaceEditingTextId, setWorkspaceEditingTextId]);

  return (
    <div className="h-full w-full flex flex-col bg-background">
      {/* Custom Toolbar */}
      <div className="p-4 bg-white border-b border-border shadow-soft flex-shrink-0" data-toolbar="true">
        <div className="flex flex-wrap gap-4 items-center">
          {/* Tool buttons using brand colors */}
          <div className="flex gap-2">
            {WORKSPACE_DEFAULTS.tools.map((tool) => (
              <button
                key={tool}
                onClick={() => handleToolChange(tool)}
                className={`px-4 py-2 rounded-md font-medium transition-colors ${
                  activeTool === tool 
                    ? 'bg-primary text-primary-foreground shadow-brand' 
                    : 'bg-muted text-muted-foreground hover:bg-gray-100 border border-border'
                }`}
              >
                {tool === 'select' && '↖️ Select'}
                {tool === 'pencil' && '✏️ Pencil'}
                {tool === 'text' && '📝 Text'}
                {tool === 'eraser' && '🧽 Eraser'}
              </button>
            ))}
            
            {/* Highlighter tool */}
            <button
              onClick={() => handleToolChange('highlighter')}
              className={`px-4 py-2 rounded-md font-medium transition-colors ${
                activeTool === 'highlighter' 
                  ? 'bg-warning text-white shadow-brand' 
                  : 'bg-muted text-muted-foreground hover:bg-gray-100 border border-border'
              }`}
            >
              🖍️ Highlighter
            </button>
          </div>

          {/* Essential Actions */}
          <div className="flex gap-2 items-center border-l border-border pl-4">
            <button
              onClick={() => excalidrawAPI?.history.undo()}
              disabled={!excalidrawAPI}
              className="p-2 rounded-md hover:bg-muted transition-colors disabled:opacity-50"
              title="Undo"
            >
              ↶
            </button>
            <button
              onClick={() => excalidrawAPI?.history.redo()}
              disabled={!excalidrawAPI}
              className="p-2 rounded-md hover:bg-muted transition-colors disabled:opacity-50"
              title="Redo"
            >
              ↷
            </button>
          </div>

          {/* Zoom Controls */}
          <div className="flex gap-2 items-center border-l border-border pl-4">
            <button
              onClick={() => {
                if (excalidrawAPI) {
                  const newZoom = Math.max(25, zoomLevel - 25);
                  excalidrawAPI.zoomToFit();
                  setZoomLevel(newZoom);
                }
              }}
              className="p-2 rounded-lg hover:bg-accent hover:text-accent-foreground transition-all duration-200 text-sm focus:ring-2 focus:ring-ring"
              title="Zoom Out"
            >
              🔍−
            </button>
            <span className="text-sm font-medium text-foreground min-w-[3rem] text-center bg-muted rounded-lg px-2 py-1">
              {zoomLevel}%
            </span>
            <button
              onClick={() => {
                if (excalidrawAPI) {
                  const newZoom = Math.min(300, zoomLevel + 25);
                  excalidrawAPI.zoomToFit();
                  setZoomLevel(newZoom);
                }
              }}
              className="p-2 rounded-lg hover:bg-accent hover:text-accent-foreground transition-all duration-200 text-sm focus:ring-2 focus:ring-ring"
              title="Zoom In"
            >
              🔍+
            </button>
          </div>

          {/* Page Navigation */}
          <div className="flex gap-2 items-center border-l border-border pl-4">
            <button
              onClick={() => setCurrentPageIndex(Math.max(0, currentPageIndex - 1))}
              disabled={currentPageIndex <= 0 || isLoadingPages}
              className="p-2 rounded-md hover:bg-muted transition-colors disabled:opacity-50 text-sm"
              title="Previous Page"
            >
              ◀
            </button>
            <span className="text-sm font-medium text-muted-foreground min-w-[3rem] text-center">
              {isLoadingPages ? "..." : `${currentPageIndex + 1} / ${pages.length}`}
            </span>
            <button
              onClick={() => setCurrentPageIndex(Math.min(pages.length - 1, currentPageIndex + 1))}
              disabled={currentPageIndex >= pages.length - 1 || isLoadingPages}
              className="p-2 rounded-md hover:bg-muted transition-colors disabled:opacity-50 text-sm"
              title="Next Page"
            >
              ▶
            </button>
            <button
              onClick={async () => {
                const newPageIndex = pages.length;
                const newPage: PageData = {
                  id: `${submissionId}-page-${newPageIndex + 1}`,
                  index: newPageIndex,
                  scene: { elements: [], appState: {} },
                  orientation: 'portrait'
                };
                
                setPages([...pages, newPage]);
                setCurrentPageIndex(newPageIndex);
                setSaveState('saving');
              }}
              disabled={isLoadingPages}
              className="p-2 rounded-md hover:bg-muted transition-colors text-sm font-medium disabled:opacity-50"
              title="Add Page"
            >
              +
            </button>
          </div>

          {/* Right-aligned actions */}
          <div className="flex gap-2 items-center ml-auto">
            {/* Clear Canvas */}
            <button
              onClick={() => {
                if (excalidrawAPI && window.confirm('Clear all content?')) {
                  excalidrawAPI.updateScene({ elements: [] });
                }
              }}
              className="px-3 py-2 rounded-md font-medium text-error hover:bg-error hover:text-white transition-colors"
              title="Clear Canvas"
            >
              🗑️ Clear
            </button>
            
            {/* Student controls */}
            <button
              onClick={() => {
                // Handle turn in logic
                setSaveState('saving');
                setTimeout(() => setSaveState('saved'), 1000);
              }}
              className="px-4 py-2 rounded-md font-medium bg-accent text-accent-foreground hover:bg-accent-light transition-colors shadow-soft"
            >
              📤 Turn In
            </button>
          </div>

          {/* Extension Hook: Future toolbar items go here */}
          <div className="flex gap-2 items-center border-l border-border pl-4" style={{display: 'none'}}>
            {/* Placeholder for Comments/Stickers/Presence UI */}
            <div className="opacity-0">🔮 Extensions</div>
          </div>

          {/* Color Controls */}
          <div className="flex gap-2 items-center border-l border-border pl-4">
            {(activeTool === 'pencil' || activeTool === 'select') && (
              <ColorPopover
                currentColor={strokeColor}
                onColorSelect={setStrokeColor}
                label="Pen"
              />
            )}
            
            {activeTool === 'text' && (
              <ColorPopover
                currentColor={safeStyle.color}
                onColorSelect={handleColorChange}
                label="Text"
                isMixed={isMixed}
              />
            )}
            
            {activeTool === 'highlighter' && (
              <ColorPopover
                currentColor={highlighterColor}
                onColorSelect={setHighlighterColor}
                label="Highlight"
              />
            )}
          </div>

          {/* Width controls with brand styling */}
          {(activeTool === 'pencil' || activeTool === 'highlighter' || activeTool === 'select') && (
            <div className="flex gap-2 items-center border-l border-border pl-4">
              <span className="text-sm font-medium text-foreground">Width:</span>
              {[1, 3, 6].map((width) => (
                <button
                  key={width}
                  onClick={() => handleWidthChange(width)}
                  className={`px-3 py-1 rounded-sm text-sm font-medium transition-colors ${
                    strokeWidth === width 
                      ? 'bg-secondary text-secondary-foreground' 
                      : 'bg-input text-muted-foreground hover:bg-gray-200'
                  }`}
                >
                  {width === 1 && 'Thin'}
                  {width === 3 && 'Med'}
                  {width === 6 && 'Thick'}
                </button>
              ))}
              
              <input
                type="range"
                min="1"
                max="10"
                value={strokeWidth || 1}
                onChange={(e) => handleWidthChange(parseInt(e.target.value))}
                className="w-16 accent-primary ml-2"
              />
              <span className="text-sm text-muted-foreground w-8">{strokeWidth}</span>
            </div>
          )}

          {/* Text styling controls */}
          {activeTool === 'text' && (
            <div className="border-l border-border pl-4">
              <TextStyleControls
                onBoldToggle={handleBoldToggle}
                onItalicToggle={handleItalicToggle}
                onUnderlineToggle={handleUnderlineToggle}
                fontSize={safeStyle.fontSize}
                onFontSizeChange={handleFontSizeChange}
                isBold={safeStyle.bold}
                isItalic={safeStyle.italic}
                isUnderlined={safeStyle.underline}
                isMixed={isMixed}
                hasSelection={hasSelection}
              />
            </div>
          )}
        </div>
      </div>
      
      {/* Excalidraw Canvas */}
      <div className="flex-1 bg-background">
          <style jsx>{`
            /* Hide Excalidraw's native toolbar and UI elements */
            :global(.excalidraw .App-toolbar) {
              display: none !important;
            }
            :global(.excalidraw .App-menu) {
              display: none !important;
            }
            :global(.excalidraw .App-menu_top) {
              display: none !important;
            }
            :global(.excalidraw .App-bottom-bar) {
              display: none !important;
            }
            :global(.excalidraw .App-toolbar-container) {
              display: none !important;
            }
            :global(.excalidraw .App-menu_left) {
              display: none !important;
            }
            :global(.excalidraw .App-menu_bottom) {
              display: none !important;
            }
            :global(.excalidraw .buttonList) {
              display: none !important;
            }
            /* Keep only the canvas visible and ensure pointer events work */
            :global(.excalidraw .excalidraw-wrapper) {
              padding: 0 !important;
              pointer-events: auto !important;
            }
            :global(.excalidraw canvas) {
              pointer-events: auto !important;
            }
            /* Hide welcome screen */
            :global(.excalidraw .welcome-screen) {
              display: none !important;
            }
            :global(.excalidraw .welcome-screen-center) {
              display: none !important;
            }
          `}</style>
          <div style={{ height: '100%', width: '100%' }}>
            <Excalidraw
              excalidrawAPI={handleExcalidrawAPIReady}
              onChange={handleChange}
              zenModeEnabled={true}
              viewModeEnabled={false}
              UIOptions={{
                canvasActions: {
                  changeViewBackgroundColor: false,
                  clearCanvas: false,
                  export: false,
                  loadScene: false,
                  saveAsImage: false,
                  saveToActiveFile: false,
                  toggleTheme: false
                },
                tools: {
                  image: false
                }
              }}
            />
          </div>
      </div>
      
      {/* Rich Text Manager V2 - handles contentEditable overlay + toolbar */}
      <RichTextManagerV2 
        excalidrawAPI={excalidrawAPI}
        isMounted={isMounted}
      />
    </div>
  );
}