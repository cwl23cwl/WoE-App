import StaticExcalidraw from "../components/StaticExcalidraw";

export default function Home() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Static Excalidraw Test</h1>
      <StaticExcalidraw />
    </main>
  );
}
