'use client'

import React from 'react'
import { StudentWorkspacePage } from '../../../src/pages/student/StudentWorkspacePage'

export default function Page() {
  return <StudentWorkspacePage />
}