import CanvasSmokeTest from '@/components/CanvasSmokeTest';

export default function CanvasPage() {
  return <CanvasSmokeTest />;
}