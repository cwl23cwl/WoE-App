import CanvasCardTest from '@/components/CanvasCardTest';

export default function CanvasCardPage() {
  return <CanvasCardTest />;
}