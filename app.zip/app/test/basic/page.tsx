export default function BasicTest() {
  return (
    <div>
      <h1>Basic Test</h1>
      <p>If you can see this, Next.js is working.</p>
    </div>
  )
}